# WordPress Customizer Controls

A collection of Cuatomizer controls that you can use with your WordPress theme or plugin.

- Multiple Select
- Textarea
- Section Header