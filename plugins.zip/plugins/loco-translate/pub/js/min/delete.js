"use strict";

!function(c, a) {
let b = a.getElementById("loco-fs");
a = a.getElementById("loco-del");
b && a && c.loco.fs.init(b).setForm(a);
}(window, document);