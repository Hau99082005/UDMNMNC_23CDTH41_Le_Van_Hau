<?php
get_header();
?>

<main id="primary" class="site-main">
    <h1>Test Page</h1>
    <p>If you can see this, WordPress is working!</p>
</main>

<?php
get_footer();
?>
