<?php
// Test PHP file
phpinfo();
?>
